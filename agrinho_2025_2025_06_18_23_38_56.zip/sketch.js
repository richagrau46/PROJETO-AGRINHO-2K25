// --- VARIÁVEIS GLOBAIS ---

// Estado do Jogo
let gameState = 'MENU'; // 'MENU', 'PLAYING', 'GAME_OVER'

// Trator
let tractor;
const TRACTOR_SPEED = 4; // Velocidade de movimento do trator
const TRACTOR_SIZE = 40; // Tamanho do trator (base para desenho)

// Colheitas (pontos)
let harvests = [];
const NUM_INITIAL_HARVESTS = 15; // Quantidade de colheitas iniciais
const HARVEST_SIZE = 20;         // Tamanho da colheita
const HARVEST_VALUE = 10;        // Pontos por colheita

// Obstáculos (pedras/buracos)
let obstacles = [];
const NUM_INITIAL_OBSTACLES = 10; // Quantidade de obstáculos iniciais
const OBSTACLE_SIZE = 30;         // Tamanho do obstáculo
const OBSTACLE_DAMAGE = 20;       // Dano por colisão com obstáculo

// Vida e Pontuação
let tractorLife = 100;
const MAX_TRACTOR_LIFE = 100;
let score = 0;

// Cores
let fieldColor;      // Cor do campo (fundo)
let harvestColor;    // Cor das colheitas
let obstacleColor;   // Cor dos obstáculos
let tractorBodyColor; // Cor do corpo do trator
let tractorWheelColor; // Cor das rodas do trator

// Botões
let playButton;
let restartButton;

// --- FUNÇÃO setup() ---
function setup() {
  createCanvas(800, 600); // Cria o canvas do jogo

  // Inicializa as cores
  fieldColor = color(120, 180, 80);      // Verde claro para o campo
  harvestColor = color(255, 200, 0);    // Amarelo para as colheitas
  obstacleColor = color(100);           // Cinza escuro para os obstáculos
  tractorBodyColor = color(200, 50, 50); // Vermelho para o corpo do trator
  tractorWheelColor = color(50);       // Preto para as rodas

  // Inicializa o objeto trator
  tractor = {
    x: width / 2,
    y: height / 2,
    size: TRACTOR_SIZE
  };

  // Inicializa os botões
  playButton = { x: width / 2, y: height / 2 + 50, w: 150, h: 60, label: "INICIAR JOGO" };
  restartButton = { x: width / 2, y: height / 2 + 50, w: 150, h: 60, label: "JOGAR NOVAMENTE" };

  // Gera os itens do campo (chamado no resetGame também)
  resetGameElements();
}

// --- FUNÇÃO draw() ---
function draw() {
  background(fieldColor); // Desenha o fundo do campo

  // Lógica principal do jogo baseada no estado
  if (gameState === 'MENU') {
    drawMenu();
  } else if (gameState === 'PLAYING') {
    updateGame();
    drawGame();
  } else if (gameState === 'GAME_OVER') {
    drawGameOver();
  }
}

// --- FUNÇÕES DE ATUALIZAÇÃO E LÓGICA DO JOGO (gameState: PLAYING) ---

function updateGame() {
  // Movimento do trator (controles do jogador)
  if (keyIsDown(LEFT_ARROW)) {
    tractor.x -= TRACTOR_SPEED;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    tractor.x += TRACTOR_SPEED;
  }
  if (keyIsDown(UP_ARROW)) {
    tractor.y -= TRACTOR_SPEED;
  }
  if (keyIsDown(DOWN_ARROW)) {
    tractor.y += TRACTOR_SPEED;
  }

  // Restringe o trator dentro dos limites do canvas
  tractor.x = constrain(tractor.x, tractor.size / 2, width - tractor.size / 2);
  tractor.y = constrain(tractor.y, tractor.size / 2, height - tractor.size / 2);

  // Verifica colisões com colheitas
  for (let i = harvests.length - 1; i >= 0; i--) {
    let h = harvests[i];
    // Calcula a distância entre o centro do trator e o centro da colheita
    let d = dist(tractor.x, tractor.y, h.x, h.y);
    if (d < tractor.size / 2 + HARVEST_SIZE / 2) { // Colisão detectada
      score += HARVEST_VALUE; // Aumenta a pontuação
      harvests.splice(i, 1); // Remove a colheita coletada
      // Adiciona uma nova colheita para manter o jogo ativo
      addRandomHarvest();
    }
  }

  // Verifica colisões com obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    let o = obstacles[i];
    let d = dist(tractor.x, tractor.y, o.x, o.y);
    if (d < tractor.size / 2 + OBSTACLE_SIZE / 2) { // Colisão detectada
      tractorLife -= OBSTACLE_DAMAGE; // Reduz a vida do trator
      obstacles.splice(i, 1); // Remove o obstáculo (para não causar dano repetido)
      // Adiciona um novo obstáculo
      addRandomObstacle();
      // Garante que a vida não seja menor que 0
      tractorLife = max(0, tractorLife); 
      
      if (tractorLife <= 0) {
        gameState = 'GAME_OVER'; // Fim de jogo se a vida zerar
      }
    }
  }
}

// --- FUNÇÕES DE DESENHO DO JOGO (gameState: PLAYING) ---

function drawGame() {
  drawHarvests();   // Desenha todas as colheitas
  drawObstacles();  // Desenha todos os obstáculos
  drawTractor();    // Desenha o trator
  drawUI();         // Desenha pontuação e barra de vida
}

// Desenha o trator
function drawTractor() {
  push(); // Salva as configurações de desenho atuais
  translate(tractor.x, tractor.y); // Move a origem para o centro do trator

  // Corpo principal do trator
  fill(tractorBodyColor);
  stroke(0);
  rect(0, 0, tractor.size * 1.5, tractor.size); // Corpo retangular

  // Cabine
  rect(-tractor.size * 0.4, -tractor.size * 0.7, tractor.size * 0.8, tractor.size * 0.6, 5); // Cabine arredondada

  // Rodas
  fill(tractorWheelColor);
  ellipse(-tractor.size * 0.6, tractor.size * 0.4, tractor.size * 0.8, tractor.size * 0.8); // Roda traseira
  ellipse(tractor.size * 0.5, tractor.size * 0.4, tractor.size * 0.6, tractor.size * 0.6); // Roda dianteira
  pop(); // Restaura as configurações de desenho
}

// Desenha todas as colheitas
function drawHarvests() {
  fill(harvestColor);
  noStroke();
  for (let h of harvests) {
    ellipse(h.x, h.y, HARVEST_SIZE);
  }
}

// Desenha todos os obstáculos
function drawObstacles() {
  fill(obstacleColor);
  noStroke();
  for (let o of obstacles) {
    ellipse(o.x, o.y, OBSTACLE_SIZE);
  }
}

// Desenha a interface do usuário (pontuação e vida)
function drawUI() {
  fill(0); // Cor do texto: preto
  textSize(24);
  textAlign(LEFT, TOP);
  text(`Pontuação: ${score}`, 10, 10);

  // Barra de Vida do Trator
  let barX = 10;
  let barY = 40;
  let barWidth = 200;
  let barHeight = 20;

  fill(150); // Fundo da barra de vida
  rect(barX, barY, barWidth, barHeight);

  // Cor da vida: verde cheia, vermelho baixa
  let lifeColor = lerpColor(color(255, 0, 0), color(0, 200, 0), tractorLife / MAX_TRACTOR_LIFE);
  fill(lifeColor);
  let currentLifeWidth = map(tractorLife, 0, MAX_TRACTOR_LIFE, 0, barWidth);
  rect(barX, barY, currentLifeWidth, barHeight);

  stroke(0);
  noFill();
  rect(barX, barY, barWidth, barHeight); // Borda da barra de vida

  fill(0); // Texto da vida
  text(`Vida: ${floor(tractorLife)}%`, barX + barWidth / 2, barY + barHeight / 2);
}

// --- FUNÇÕES DE TELAS DE ESTADO DO JOGO ---

function drawMenu() {
  fill(0);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("Trator na Fazenda", width / 2, height / 2 - 50);

  drawButton(playButton.x, playButton.y, playButton.w, playButton.h, playButton.label, mouseIsOver(playButton));
}

function drawGameOver() {
  fill(200, 0, 0); // Fundo vermelho para Game Over
  rect(0, 0, width, height); // Preenche a tela toda
  
  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("GAME OVER!", width / 2, height / 2 - 50);
  textSize(32);
  text(`Pontuação Final: ${score}`, width / 2, height / 2);

  drawButton(restartButton.x, restartButton.y, restartButton.w, restartButton.h, restartButton.label, mouseIsOver(restartButton));
}

// --- FUNÇÕES DE UTILIDADE E INTERAÇÃO ---

// Gera uma colheita em uma posição aleatória
function addRandomHarvest() {
  harvests.push({
    x: random(HARVEST_SIZE / 2, width - HARVEST_SIZE / 2),
    y: random(HARVEST_SIZE / 2, height - HARVEST_SIZE / 2)
  });
}

// Gera um obstáculo em uma posição aleatória
function addRandomObstacle() {
  obstacles.push({
    x: random(OBSTACLE_SIZE / 2, width - OBSTACLE_SIZE / 2),
    y: random(OBSTACLE_SIZE / 2, height - OBSTACLE_SIZE / 2)
  });
}

// Reseta os elementos do jogo (colheitas, obstáculos, vida, pontuação)
function resetGameElements() {
  harvests = [];
  obstacles = [];
  tractorLife = MAX_TRACTOR_LIFE;
  score = 0;
  tractor.x = width / 2;
  tractor.y = height / 2;

  for (let i = 0; i < NUM_INITIAL_HARVESTS; i++) {
    addRandomHarvest();
  }
  for (let i = 0; i < NUM_INITIAL_OBSTACLES; i++) {
    addRandomObstacle();
  }
}

// Verifica se o mouse está sobre um botão
function mouseIsOver(button) {
  // Ajuste para rectMode(CENTER)
  return mouseX > button.x - button.w / 2 && mouseX < button.x + button.w / 2 &&
         mouseY > button.y - button.h / 2 && mouseY < button.y + button.h / 2;
}

// Desenha um botão genérico
function drawButton(x, y, w, h, label, isHovered) {
    push();
    rectMode(CENTER); // Desenha o retângulo do centro
    if (isHovered && mouseIsPressed) {
        fill(100, 200, 100); // Cor mais escura quando clicado
    } else if (isHovered) {
        fill(150, 255, 150); // Cor clara quando hover
    } else {
        fill(120, 220, 120); // Cor padrão
    }
    stroke(0);
    rect(x, y, w, h, 8); // Botão com cantos arredondados

    fill(0);
    textSize(18);
    textAlign(CENTER, CENTER);
    text(label, x, y);
    pop();
}

// Lida com cliques do mouse (para os botões)
function mousePressed() {
  if (gameState === 'MENU') {
    if (mouseIsOver(playButton)) {
      gameState = 'PLAYING';
      resetGameElements(); // Começa o jogo, resetando elementos
    }
  } else if (gameState === 'GAME_OVER') {
    if (mouseIsOver(restartButton)) {
      gameState = 'PLAYING';
      resetGameElements(); // Reinicia o jogo
    }
  }
}